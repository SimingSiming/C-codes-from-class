#include <iostream>
#include <string>
#include <cctype>
using namespace std;

// MISSING FUNCTION DECLARATIONS HERE (you can remove these comments)

int main()
{
    string sentence;
    // MISSING (short) CODE HERE TO GET SENTENCE FROM USER (you can remove these comments)

    sort_string(sentence, sentence.size());
    print_freq(sentence, sentence.size());

	return 0;
}

// MISSING FUNCTION DEFINITIONS HERE (you can remove these comments)
