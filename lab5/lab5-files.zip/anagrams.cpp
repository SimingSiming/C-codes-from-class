#include <iostream>
#include <string>
#include <cctype>
using namespace std;

// MISSING FUNCTION DECLARATIONS HERE (you can remove these comments)

int main()
{
    // MISSING CODE HERE (you can remove these comments)
	// Get strings from user
	// Clean strings
	// Check to see if they are anagrams
	// Report if they are or not anagrams

    return 0;
}

// MISSING FUNCTION DEFINITIONS HERE (you can remove these comments)
