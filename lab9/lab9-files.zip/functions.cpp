// Define your FOUR functions here (no more, no less):
// First, the 3 functions for the selectionSort:
// swap_values, find_index_of_swap, sort


// Next, define the function getArray here. 
// This is the same one we used in Lab 4, so you can copy it over as is.
