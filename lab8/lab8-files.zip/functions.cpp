// Place your member function and program function definitions here:
//  1. The 2 Constructors
//  2. Member function getAString
//  3. Member function cleanUp
//  4. Member function countLetters 
//  5. Program function compareCounts
// See lab description for details
//

